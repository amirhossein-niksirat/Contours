import pickle

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

df = pd.read_csv("BNB-USD.csv")

X = df[["Open", "Low", "High", "Volume"]]
y = df["Close"]
# X = np.arange(len(y)).reshape(-1,1)

model = LinearRegression()

model.fit(X,y)
score = model.score(X, y)* 100
print(score)

# X = X[0:400]
predict = model.predict(X)

r = np.arange(len(X))

plt.plot(r,y, label="Real")
plt.plot(r,predict, label="Predict")
plt.legend()
plt.plot()
plt.show()


# write(dump) binary object to file
file = open("linear_model.txt", "wb")
pickle.dump(model,file)
file.close()

