import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold

# Date,Open,High,Low,Close,Adj Close,Volume

df = pd.read_csv("BNB-USD.csv")

X = df[[ "Open", "Volume"]]
y = df["Close"]

x_train, x_test,y_train,y_test = train_test_split(X,y,train_size=0.8)
kfold = KFold(p=5)
kfold.get_n_splits(x_train)

model = LinearRegression()
model.fit(x_train, y_train)
score = model.score(x_test, y_test)
print("Score : ",score*100)
predict = model.predict(X)

df["Close"].plot()
plt.plot(predict, label="Predict")
plt.legend()
plt.show()