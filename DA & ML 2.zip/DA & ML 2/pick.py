import pickle
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

df = pd.read_csv("BNB-USD.csv")
df = [1,2,3,4]
print(df[0:2])

# w write
# r read
# b binary
# t text

# write(dump) binary object to file
file = open("test.txt", "wb")
pickle.dump(df,file)
file.close()

# read(load) binary object from file
file = open("test.txt", "rb")
data = pickle.load(file)
file.close()

# print(data["Open"].head(20))
print(data[0:2])
print(type(data))
