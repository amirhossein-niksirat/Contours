import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# df = pd.read_csv("BNB-USD.csv")
df = [1,2,3,4]
print(df[0:2])

file = open("test.txt", "wt")
file.write(str(df))
file.close()

file = open("test.txt", "rt")
data = file.read()
file.close()
print(data[0:2])
print(type(data))
