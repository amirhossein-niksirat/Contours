import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

X = np.arange(0, 100).reshape(-1, 1)
# y= 2.x + 3
y = X** 2 * 2 + 3


model = LinearRegression()

model.fit(X, y)

predict = model.predict(X)

plt.plot(X, y, label="Real")
plt.plot(X, predict, label="Predict")
plt.legend()
plt.plot()
plt.show()

# y = mx + b
m = model.coef_
b = model.intercept_

print(f"y = {m}.x + {b}")
