from sklearn.linear_model import LinearRegression
from matplotlib import pyplot as plt
import pickle
import numpy as np
import pandas as pd

df = pd.read_csv("BNB-USD.csv")
X = df[["Open", "Low", "High", "Volume"]]


file = open ("linear_model.txt", "rb")
model = pickle.load(file)

print(model)
print(type(model))


predict = model.predict(X)

plt.plot(range(len(X)), predict)
plt.show()
