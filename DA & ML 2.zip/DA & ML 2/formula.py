import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

df = pd.read_csv("BNB-USD.csv")

y = df["Close"]
X = np.arange(len(y)).reshape(-1,1)

model = LinearRegression()

model.fit(X,y)

predict = model.predict(X)

plt.plot(X,y, label="Real")
plt.plot(X,predict, label="Predict")
plt.legend()
plt.plot()
plt.show()


# y = mx + b
m = model.coef_
b = model.intercept_

print(f"y = {m}.x + {b}")
