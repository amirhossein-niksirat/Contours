import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

df = pd.read_csv("BNB-USD.csv")


X = df["Open"].to_numpy()
plt.plot(X,"--",label= "Real")

c1 = np.array([0.15, 0.7, 0.15])
result = [X[0]]
for i in range(len(X) - 2):
    result.append(sum(c1 * X[i:i + 3]))
result.append(X[-1])
plt.plot(result,label= "Gaus C1")

c2 = np.array([1/4, 1/2, 1/4])
result = [X[0]]
for i in range(len(X) - 2):
    result.append(sum(c2 * X[i:i + 3]))
result.append(X[-1])
plt.plot(result,label= "Gaus C2")

c3 = np.array([1/3, 1/3, 1/3])
result = [X[0]]
for i in range(len(X) - 2):
    result.append(sum(c3 * X[i:i + 3]))
result.append(X[-1])
plt.plot(result,label= "Blur C3")

plt.legend()
plt.show()
