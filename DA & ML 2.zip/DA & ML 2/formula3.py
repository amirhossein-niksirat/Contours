import numpy as np
import matplotlib.pyplot as plt


X = np.arange(0, 100)
# y= 4.x^2 + 3x - 5
y = 4 * X ** 2  + 3 * X - 5
X = list(X)

plt.plot(X, y, label="Real")

model = np.polyfit(X,y,2)
print(model)
# print(model.coefficients)

# plt.plot(X, predict, label="Predict")
# plt.legend()
# plt.plot()
# plt.show()

a,b,c= model

# y = ax^2 + bx + c
print(f"y = {a}.x^2 + {b}.x + {c} ")

X = df["Open"]
df["close"] = a * X**2 + b * X + c